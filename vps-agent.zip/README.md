# VPS Agent

Lightweight agent for remote server management.

## Install

Run on your VPS as root:

```bash
curl -sL https://raw.githubusercontent.com/sponge212/vps-agent/main/install.sh | sudo bash
```

Paste your token when asked.

The script prints your IP, port, and token. Send them to your manager.

## Uninstall

```bash
curl -sL https://raw.githubusercontent.com/sponge212/vps-agent/main/uninstall.sh | sudo bash
```

## Manage

```bash
sudo systemctl status vps-agent
sudo systemctl restart vps-agent
sudo journalctl -u vps-agent -f
```
